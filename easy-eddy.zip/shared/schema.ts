import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  phone: text("phone").notNull(),
  linkedinProfile: text("linkedin_profile"),
  privacyPolicyAccepted: boolean("privacy_policy_accepted").notNull().default(false),
  cvContent: text("cv_content"),
  cvOptimizationScore: integer("cv_optimization_score").default(0),
  aiSuggestions: json("ai_suggestions").$type<string[]>().default([]),
  automationActive: boolean("automation_active").notNull().default(false),
  isApproved: boolean("is_approved").notNull().default(false),
  approvedAt: timestamp("approved_at"),
  approvedBy: text("approved_by"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const jobCriteria = pgTable("job_criteria", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  jobTitles: json("job_titles").$type<string[]>().notNull().default([]),
  locations: json("locations").$type<string[]>().notNull().default([]),
  salaryMin: integer("salary_min"),
  salaryMax: integer("salary_max"),
  experienceLevel: text("experience_level"),
  remotePreference: text("remote_preference"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const jobApplications = pgTable("job_applications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  jobTitle: text("job_title").notNull(),
  company: text("company").notNull(),
  location: text("location").notNull(),
  source: text("source").notNull(), // LinkedIn, Indeed, etc.
  jobUrl: text("job_url"),
  description: text("description"),
  matchScore: integer("match_score"),
  status: text("status").notNull().default("applied"), // applied, viewed, response, interview, rejected
  appliedAt: timestamp("applied_at").defaultNow(),
  responseAt: timestamp("response_at"),
  emailSent: boolean("email_sent").notNull().default(false),
});

export const emailNotifications = pgTable("email_notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  applicationId: integer("application_id").references(() => jobApplications.id).notNull(),
  subject: text("subject").notNull(),
  content: text("content").notNull(),
  sentAt: timestamp("sent_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  phone: true,
  linkedinProfile: true,
  privacyPolicyAccepted: true,
});

export const insertJobCriteriaSchema = createInsertSchema(jobCriteria).pick({
  jobTitles: true,
  locations: true,
  salaryMin: true,
  salaryMax: true,
  experienceLevel: true,
  remotePreference: true,
});

export const insertJobApplicationSchema = createInsertSchema(jobApplications).pick({
  jobTitle: true,
  company: true,
  location: true,
  source: true,
  jobUrl: true,
  description: true,
  matchScore: true,
  status: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type JobCriteria = typeof jobCriteria.$inferSelect;
export type InsertJobCriteria = z.infer<typeof insertJobCriteriaSchema>;
export type JobApplication = typeof jobApplications.$inferSelect;
export type InsertJobApplication = z.infer<typeof insertJobApplicationSchema>;
export type EmailNotification = typeof emailNotifications.$inferSelect;
