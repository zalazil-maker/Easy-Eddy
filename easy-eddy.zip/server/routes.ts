import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertJobCriteriaSchema } from "@shared/schema";
import { optimizeCV } from "./services/openai";
import { searchAndApplyJobs, simulateJobResponses } from "./services/jobSearch";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error: any) {
      res.status(400).json({ message: "Invalid user data", error: error.message });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error: any) {
      res.status(500).json({ message: "Server error", error: error.message });
    }
  });

  app.patch("/api/users/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const user = await storage.updateUser(id, updates);
      res.json(user);
    } catch (error: any) {
      res.status(400).json({ message: "Update failed", error: error.message });
    }
  });

  // CV optimization route
  app.post("/api/users/:id/optimize-cv", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { cvContent } = req.body;
      
      if (!cvContent) {
        return res.status(400).json({ message: "CV content is required" });
      }

      const criteria = await storage.getJobCriteria(id);
      const targetJobs = criteria?.jobTitles || ["Software Developer"];
      
      const optimization = await optimizeCV(cvContent, targetJobs);
      
      // Update user with CV and optimization results
      await storage.updateUser(id, {
        cvContent,
        cvOptimizationScore: optimization.optimizationScore,
        aiSuggestions: optimization.suggestions
      });

      res.json(optimization);
    } catch (error: any) {
      res.status(500).json({ message: "CV optimization failed", error: error.message });
    }
  });

  // Job criteria routes
  app.get("/api/users/:id/job-criteria", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const criteria = await storage.getJobCriteria(userId);
      res.json(criteria);
    } catch (error: any) {
      res.status(500).json({ message: "Server error", error: error.message });
    }
  });

  app.post("/api/users/:id/job-criteria", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const criteriaData = insertJobCriteriaSchema.parse(req.body);
      const criteria = await storage.createJobCriteria({ ...criteriaData, userId });
      res.json(criteria);
    } catch (error: any) {
      res.status(400).json({ message: "Invalid criteria data", error: error.message });
    }
  });

  app.patch("/api/users/:id/job-criteria", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const updates = req.body;
      const criteria = await storage.updateJobCriteria(userId, updates);
      res.json(criteria);
    } catch (error: any) {
      res.status(400).json({ message: "Update failed", error: error.message });
    }
  });

  // Job applications routes
  app.get("/api/users/:id/applications", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const applications = await storage.getJobApplications(userId);
      res.json(applications);
    } catch (error: any) {
      res.status(500).json({ message: "Server error", error: error.message });
    }
  });

  // Email notifications routes
  app.get("/api/users/:id/notifications", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const notifications = await storage.getEmailNotifications(userId);
      res.json(notifications);
    } catch (error: any) {
      res.status(500).json({ message: "Server error", error: error.message });
    }
  });

  // User stats route
  app.get("/api/users/:id/stats", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ message: "Server error", error: error.message });
    }
  });

  // Automation control routes
  app.post("/api/users/:id/start-automation", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Update user automation status
      await storage.updateUser(userId, { automationActive: true });
      
      // Start job search and application process
      await searchAndApplyJobs(userId);
      
      // Simulate some job responses for demonstration
      setTimeout(() => {
        simulateJobResponses(userId);
      }, 5000);
      
      res.json({ message: "Automation started successfully" });
    } catch (error: any) {
      res.status(500).json({ message: "Failed to start automation", error: error.message });
    }
  });

  app.post("/api/users/:id/stop-automation", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      await storage.updateUser(userId, { automationActive: false });
      res.json({ message: "Automation stopped successfully" });
    } catch (error: any) {
      res.status(500).json({ message: "Failed to stop automation", error: error.message });
    }
  });

  // Admin routes (protected by frontend authentication)
  app.get("/api/admin/users", async (req, res) => {
    try {
      const allUsers = Array.from((storage as any).users.values());
      res.json(allUsers);
    } catch (error: any) {
      res.status(500).json({ message: "Server error", error: error.message });
    }
  });

  app.get("/api/admin/pending-users", async (req, res) => {
    try {
      const pendingUsers = await storage.getAllPendingUsers();
      res.json(pendingUsers);
    } catch (error: any) {
      res.status(500).json({ message: "Server error", error: error.message });
    }
  });

  app.post("/api/admin/approve-user/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const approvedUser = await storage.approveUser(userId, "admin");
      res.json(approvedUser);
    } catch (error: any) {
      res.status(500).json({ message: "Server error", error: error.message });
    }
  });

  app.get("/api/admin/applications", async (req, res) => {
    try {
      const allApplications = Array.from((storage as any).jobApplications.values());
      res.json(allApplications);
    } catch (error: any) {
      res.status(500).json({ message: "Server error", error: error.message });
    }
  });

  app.get("/api/admin/stats", async (req, res) => {
    try {
      const users = Array.from((storage as any).users.values());
      const applications = Array.from((storage as any).jobApplications.values());
      
      const stats = {
        totalUsers: users.length,
        totalApplications: applications.length,
        activeAutomations: users.filter((u: any) => u.automationActive).length,
        successRate: applications.length ? 
          Math.round((applications.filter((a: any) => a.status === "response" || a.status === "interview").length / applications.length) * 100) : 0
      };
      
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ message: "Server error", error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
