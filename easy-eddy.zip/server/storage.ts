import { 
  users, 
  jobCriteria, 
  jobApplications, 
  emailNotifications,
  type User, 
  type InsertUser,
  type JobCriteria,
  type InsertJobCriteria,
  type JobApplication,
  type InsertJobApplication,
  type EmailNotification
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User>;
  approveUser(id: number, approvedBy: string): Promise<User>;
  getAllPendingUsers(): Promise<User[]>;
  
  // Job criteria operations
  getJobCriteria(userId: number): Promise<JobCriteria | undefined>;
  createJobCriteria(criteria: InsertJobCriteria & { userId: number }): Promise<JobCriteria>;
  updateJobCriteria(userId: number, updates: Partial<JobCriteria>): Promise<JobCriteria>;
  
  // Job application operations
  getJobApplications(userId: number): Promise<JobApplication[]>;
  createJobApplication(application: InsertJobApplication & { userId: number }): Promise<JobApplication>;
  updateJobApplication(id: number, updates: Partial<JobApplication>): Promise<JobApplication>;
  
  // Email notification operations
  getEmailNotifications(userId: number): Promise<EmailNotification[]>;
  createEmailNotification(notification: { userId: number; applicationId: number; subject: string; content: string }): Promise<EmailNotification>;
  
  // Stats operations
  getUserStats(userId: number): Promise<{
    applicationsSent: number;
    responses: number;
    interviews: number;
    activeSearches: number;
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private jobCriteria: Map<number, JobCriteria>;
  private jobApplications: Map<number, JobApplication>;
  private emailNotifications: Map<number, EmailNotification>;
  private currentUserId: number;
  private currentCriteriaId: number;
  private currentApplicationId: number;
  private currentNotificationId: number;

  constructor() {
    this.users = new Map();
    this.jobCriteria = new Map();
    this.jobApplications = new Map();
    this.emailNotifications = new Map();
    this.currentUserId = 1;
    this.currentCriteriaId = 1;
    this.currentApplicationId = 1;
    this.currentNotificationId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = {
      ...insertUser,
      id,
      linkedinProfile: insertUser.linkedinProfile || null,
      privacyPolicyAccepted: insertUser.privacyPolicyAccepted || false,
      cvContent: null,
      cvOptimizationScore: 0,
      aiSuggestions: [],
      automationActive: false,
      isApproved: false,
      approvedAt: null,
      approvedBy: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User> {
    const user = this.users.get(id);
    if (!user) {
      throw new Error("User not found");
    }
    const updatedUser = { ...user, ...updates, updatedAt: new Date() };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async approveUser(id: number, approvedBy: string): Promise<User> {
    const user = this.users.get(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser = { 
      ...user, 
      isApproved: true, 
      approvedAt: new Date(),
      approvedBy,
      updatedAt: new Date()
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getAllPendingUsers(): Promise<User[]> {
    return Array.from(this.users.values()).filter(user => !user.isApproved);
  }

  async getJobCriteria(userId: number): Promise<JobCriteria | undefined> {
    return Array.from(this.jobCriteria.values()).find(criteria => criteria.userId === userId);
  }

  async createJobCriteria(criteria: InsertJobCriteria & { userId: number }): Promise<JobCriteria> {
    const id = this.currentCriteriaId++;
    const jobCriteria: JobCriteria = {
      id,
      userId: criteria.userId,
      jobTitles: criteria.jobTitles as string[],
      locations: criteria.locations as string[],
      salaryMin: criteria.salaryMin || null,
      salaryMax: criteria.salaryMax || null,
      experienceLevel: criteria.experienceLevel || null,
      remotePreference: criteria.remotePreference || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.jobCriteria.set(id, jobCriteria);
    return jobCriteria;
  }

  async updateJobCriteria(userId: number, updates: Partial<JobCriteria>): Promise<JobCriteria> {
    const criteria = await this.getJobCriteria(userId);
    if (!criteria) {
      throw new Error("Job criteria not found");
    }
    const updatedCriteria = { ...criteria, ...updates, updatedAt: new Date() };
    this.jobCriteria.set(criteria.id, updatedCriteria);
    return updatedCriteria;
  }

  async getJobApplications(userId: number): Promise<JobApplication[]> {
    return Array.from(this.jobApplications.values())
      .filter(app => app.userId === userId)
      .sort((a, b) => b.appliedAt!.getTime() - a.appliedAt!.getTime());
  }

  async createJobApplication(application: InsertJobApplication & { userId: number }): Promise<JobApplication> {
    const id = this.currentApplicationId++;
    const jobApplication: JobApplication = {
      id,
      userId: application.userId,
      jobTitle: application.jobTitle,
      company: application.company,
      location: application.location,
      source: application.source,
      jobUrl: application.jobUrl || null,
      description: application.description || null,
      matchScore: application.matchScore || null,
      status: application.status || "applied",
      appliedAt: new Date(),
      responseAt: null,
      emailSent: false,
    };
    this.jobApplications.set(id, jobApplication);
    return jobApplication;
  }

  async updateJobApplication(id: number, updates: Partial<JobApplication>): Promise<JobApplication> {
    const application = this.jobApplications.get(id);
    if (!application) {
      throw new Error("Job application not found");
    }
    const updatedApplication = { ...application, ...updates };
    this.jobApplications.set(id, updatedApplication);
    return updatedApplication;
  }

  async getEmailNotifications(userId: number): Promise<EmailNotification[]> {
    return Array.from(this.emailNotifications.values())
      .filter(notification => notification.userId === userId)
      .sort((a, b) => b.sentAt!.getTime() - a.sentAt!.getTime());
  }

  async createEmailNotification(notification: { userId: number; applicationId: number; subject: string; content: string }): Promise<EmailNotification> {
    const id = this.currentNotificationId++;
    const emailNotification: EmailNotification = {
      ...notification,
      id,
      sentAt: new Date(),
    };
    this.emailNotifications.set(id, emailNotification);
    return emailNotification;
  }

  async getUserStats(userId: number): Promise<{
    applicationsSent: number;
    responses: number;
    interviews: number;
    activeSearches: number;
  }> {
    const applications = await this.getJobApplications(userId);
    const criteria = await this.getJobCriteria(userId);
    
    return {
      applicationsSent: applications.length,
      responses: applications.filter(app => app.status === "response").length,
      interviews: applications.filter(app => app.status === "interview").length,
      activeSearches: criteria ? criteria.jobTitles.length : 0,
    };
  }
}

export const storage = new MemStorage();
