import { storage } from "../storage";
import { sendApplicationNotification } from "./email";
import type { InsertJobApplication } from "@shared/schema";

// Mock job data for demonstration - in real implementation, this would scrape actual job sites
const mockJobs = [
  {
    jobTitle: "Senior Frontend Developer",
    company: "TechCorp Inc.",
    location: "San Francisco, CA",
    source: "LinkedIn",
    jobUrl: "https://linkedin.com/jobs/123456",
    description: "We're looking for a skilled Frontend Developer with React experience...",
    matchScore: 94
  },
  {
    jobTitle: "Full Stack Engineer",
    company: "StartupXYZ",
    location: "Remote",
    source: "Indeed",
    jobUrl: "https://indeed.com/jobs/789012",
    description: "Join our dynamic team as a Full Stack Engineer...",
    matchScore: 87
  },
  {
    jobTitle: "React Developer",
    company: "Digital Agency Pro",
    location: "New York, NY",
    source: "Glassdoor",
    jobUrl: "https://glassdoor.com/jobs/345678",
    description: "Exciting opportunity for a React Developer...",
    matchScore: 91
  },
  {
    jobTitle: "Frontend Engineer",
    company: "InnovateTech",
    location: "Austin, TX",
    source: "LinkedIn",
    jobUrl: "https://linkedin.com/jobs/901234",
    description: "We're seeking a Frontend Engineer to join our team...",
    matchScore: 88
  },
  {
    jobTitle: "JavaScript Developer",
    company: "WebSolutions LLC",
    location: "Remote",
    source: "Indeed",
    jobUrl: "https://indeed.com/jobs/567890",
    description: "Looking for a JavaScript Developer with modern framework experience...",
    matchScore: 85
  }
];

export async function searchAndApplyJobs(userId: number): Promise<void> {
  try {
    const user = await storage.getUser(userId);
    const criteria = await storage.getJobCriteria(userId);
    
    if (!user || !criteria) {
      throw new Error("User or job criteria not found");
    }

    // In real implementation, this would search actual job sites
    // For now, we'll simulate finding relevant jobs
    const relevantJobs = mockJobs.filter(job => {
      // Check if job title matches criteria
      const titleMatch = criteria.jobTitles.some(title => 
        job.jobTitle.toLowerCase().includes(title.toLowerCase())
      );
      
      // Check if location matches criteria
      const locationMatch = criteria.locations.some(location => 
        job.location.toLowerCase().includes(location.toLowerCase()) ||
        location.toLowerCase() === "remote"
      );
      
      return titleMatch && locationMatch;
    });

    console.log(`Found ${relevantJobs.length} relevant jobs for user ${userId}`);

    // Apply to each relevant job
    for (const job of relevantJobs) {
      // Check if we already applied to this job (simple check by company + title)
      const existingApplications = await storage.getJobApplications(userId);
      const alreadyApplied = existingApplications.some(app => 
        app.company === job.company && app.jobTitle === job.jobTitle
      );

      if (!alreadyApplied) {
        // Create job application
        const application = await storage.createJobApplication({
          userId,
          jobTitle: job.jobTitle,
          company: job.company,
          location: job.location,
          source: job.source,
          jobUrl: job.jobUrl,
          description: job.description,
          matchScore: job.matchScore,
          status: "applied"
        });

        // Send email notification
        await sendApplicationNotification(userId, application.id);
        
        console.log(`Applied to ${job.jobTitle} at ${job.company}`);
      }
    }
  } catch (error) {
    console.error("Job search and application error:", error);
  }
}

export async function simulateJobResponses(userId: number): Promise<void> {
  try {
    const applications = await storage.getJobApplications(userId);
    
    // Simulate some responses for demonstration
    for (const app of applications) {
      if (app.status === "applied" && Math.random() < 0.3) { // 30% chance of response
        const responseType = Math.random() < 0.7 ? "response" : "interview";
        await storage.updateJobApplication(app.id, {
          status: responseType,
          responseAt: new Date()
        });
        
        console.log(`Simulated ${responseType} for ${app.jobTitle} at ${app.company}`);
      }
    }
  } catch (error) {
    console.error("Job response simulation error:", error);
  }
}
