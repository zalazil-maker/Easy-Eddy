import { storage } from "../storage";
import { generateJobSummary } from "./openai";

export async function sendApplicationNotification(userId: number, applicationId: number): Promise<void> {
  try {
    const user = await storage.getUser(userId);
    const applications = await storage.getJobApplications(userId);
    const application = applications.find(app => app.id === applicationId);
    
    if (!user || !application) {
      throw new Error("User or application not found");
    }

    const jobSummary = await generateJobSummary(
      application.jobTitle,
      application.company,
      application.description || "",
      application.matchScore || 0
    );

    const subject = `Job Application Sent: ${application.jobTitle} at ${application.company}`;
    const content = `
Dear ${user.email},

Easy Eddy has successfully submitted your application for the following position:

**Job Title:** ${application.jobTitle}
**Company:** ${application.company}
**Location:** ${application.location}
**Source:** ${application.source}
**Match Score:** ${application.matchScore}%
**Applied:** ${application.appliedAt?.toLocaleString()}

**Job Summary:**
${jobSummary}

**Application Details:**
${application.jobUrl ? `Job URL: ${application.jobUrl}` : ""}

This application was automatically submitted based on your job search criteria. We'll notify you of any responses or updates.

Best regards,
Easy Eddy Team

---
This is an automated message from Easy Eddy's job application system.
    `;

    // In a real implementation, this would send an actual email
    // For now, we'll store the notification in our system
    await storage.createEmailNotification({
      userId,
      applicationId,
      subject,
      content
    });

    // Mark application as email sent
    await storage.updateJobApplication(applicationId, { emailSent: true });

    console.log(`Email notification sent to ${user.email} for application ${applicationId}`);
  } catch (error) {
    console.error("Failed to send application notification:", error);
  }
}

export async function sendBulkApplicationNotifications(userId: number, applicationIds: number[]): Promise<void> {
  for (const applicationId of applicationIds) {
    await sendApplicationNotification(userId, applicationId);
  }
}
