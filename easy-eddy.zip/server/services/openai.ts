import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export async function optimizeCV(cvContent: string, targetJobs: string[]): Promise<{
  optimizationScore: number;
  suggestions: string[];
}> {
  try {
    const prompt = `
    Analyze the following CV/resume and provide optimization suggestions for the target job titles: ${targetJobs.join(", ")}.
    
    CV Content:
    ${cvContent}
    
    Please provide:
    1. An optimization score from 0-100 (100 being perfect)
    2. Specific, actionable suggestions to improve the CV for the target roles
    
    Respond in JSON format: {
      "optimizationScore": number,
      "suggestions": [string array of specific suggestions]
    }
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a professional CV optimization expert. Provide detailed, actionable advice to improve job application success rates."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      optimizationScore: Math.max(0, Math.min(100, result.optimizationScore || 0)),
      suggestions: Array.isArray(result.suggestions) ? result.suggestions : []
    };
  } catch (error) {
    console.error("CV optimization error:", error);
    return {
      optimizationScore: 0,
      suggestions: ["Error analyzing CV. Please try again."]
    };
  }
}

export async function generateJobSummary(jobTitle: string, company: string, description: string, matchScore: number): Promise<string> {
  try {
    const prompt = `
    Create a professional email summary for a job application that was automatically submitted.
    
    Job Details:
    - Title: ${jobTitle}
    - Company: ${company}
    - Description: ${description}
    - Match Score: ${matchScore}%
    
    Create a concise, professional summary explaining:
    1. What the job is about
    2. Why it was a good match
    3. Key requirements/responsibilities
    
    Keep it under 200 words and professional.
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a professional job application assistant. Create clear, concise job summaries for email notifications."
        },
        {
          role: "user",
          content: prompt
        }
      ],
    });

    return response.choices[0].message.content || "Job application summary unavailable.";
  } catch (error) {
    console.error("Job summary generation error:", error);
    return "Job application summary unavailable due to processing error.";
  }
}
