import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";
import { insertUserSchema } from "@shared/schema";

const contactInfoSchema = insertUserSchema.extend({
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().min(10, "Please enter a valid phone number"),
});

interface ContactInfoProps {
  data: any;
  onUpdate: (updates: any) => void;
}

export default function ContactInfo({ data, onUpdate }: ContactInfoProps) {
  const form = useForm({
    resolver: zodResolver(contactInfoSchema),
    defaultValues: {
      email: data.email || "",
      phone: data.phone || "",
      linkedinProfile: data.linkedinProfile || "",
      privacyPolicyAccepted: data.privacyPolicyAccepted || false,
    },
  });

  const handleInputChange = (field: string, value: any) => {
    form.setValue(field as any, value);
    onUpdate({ [field]: value });
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="email" className="text-sm font-medium text-gray-700">
          Email Address *
        </Label>
        <Input
          id="email"
          type="email"
          required
          value={data.email}
          onChange={(e) => handleInputChange("email", e.target.value)}
          placeholder="john.doe@email.com"
          className="mt-1"
        />
        {form.formState.errors.email && (
          <p className="text-sm text-red-600 mt-1">{form.formState.errors.email.message}</p>
        )}
      </div>

      <div>
        <Label htmlFor="phone" className="text-sm font-medium text-gray-700">
          Phone Number *
        </Label>
        <Input
          id="phone"
          type="tel"
          required
          value={data.phone}
          onChange={(e) => handleInputChange("phone", e.target.value)}
          placeholder="+1 (555) 123-4567"
          className="mt-1"
        />
        {form.formState.errors.phone && (
          <p className="text-sm text-red-600 mt-1">{form.formState.errors.phone.message}</p>
        )}
      </div>

      <div>
        <Label htmlFor="linkedin" className="text-sm font-medium text-gray-700">
          LinkedIn Profile (Optional)
        </Label>
        <Input
          id="linkedin"
          type="url"
          value={data.linkedinProfile}
          onChange={(e) => handleInputChange("linkedinProfile", e.target.value)}
          placeholder="https://linkedin.com/in/yourprofile"
          className="mt-1"
        />
      </div>

      <Card className="bg-gray-50">
        <CardContent className="p-4">
          <div className="flex items-start space-x-3">
            <Checkbox
              id="privacy"
              checked={data.privacyPolicyAccepted}
              onCheckedChange={(checked) => handleInputChange("privacyPolicyAccepted", checked)}
              className="mt-1"
            />
            <Label htmlFor="privacy" className="text-sm text-gray-700">
              I agree to the{" "}
              <a href="#" className="text-brand-green hover:text-brand-green-dark">
                Privacy Policy
              </a>{" "}
              and understand that Easy Eddy will use my information to apply for jobs on my behalf and send me notifications.
            </Label>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
