import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { CloudUpload, FileText, Lightbulb } from "lucide-react";

interface CVUploadProps {
  data: any;
  onUpdate: (updates: any) => void;
}

export default function CVUpload({ data, onUpdate }: CVUploadProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [optimizationResult, setOptimizationResult] = useState<any>(null);
  const { toast } = useToast();

  const optimizeCVMutation = useMutation({
    mutationFn: async (cvContent: string) => {
      const response = await apiRequest("POST", "/api/users/1/optimize-cv", { cvContent });
      return response.json();
    },
    onSuccess: (result) => {
      setOptimizationResult(result);
      onUpdate({ cvContent: selectedFile ? "CV uploaded and optimized" : "" });
      toast({
        title: "CV Optimized",
        description: `Your CV has been analyzed with a score of ${result.optimizationScore}%`,
      });
    },
    onError: (error) => {
      toast({
        title: "Optimization Failed",
        description: "Failed to optimize CV. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const allowedTypes = ["application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"];
      const maxSize = 10 * 1024 * 1024; // 10MB

      if (!allowedTypes.includes(file.type)) {
        toast({
          title: "Invalid File Type",
          description: "Please upload a PDF, DOC, or DOCX file.",
          variant: "destructive",
        });
        return;
      }

      if (file.size > maxSize) {
        toast({
          title: "File Too Large",
          description: "Please upload a file smaller than 10MB.",
          variant: "destructive",
        });
        return;
      }

      setSelectedFile(file);
      
      // For demo purposes, we'll simulate CV content
      const mockCVContent = `
        John Doe
        Senior Software Engineer
        
        Experience:
        - 5+ years of frontend development
        - Expert in React, TypeScript, and modern web technologies
        - Led team of 4 developers on multiple projects
        - Implemented responsive designs and optimized performance
        
        Skills:
        - JavaScript, TypeScript, React, Node.js
        - HTML5, CSS3, Tailwind CSS
        - Git, Docker, AWS
        - Team leadership and project management
        
        Education:
        - Bachelor's in Computer Science
        - Various technical certifications
      `;
      
      optimizeCVMutation.mutate(mockCVContent);
    }
  };

  const handleUploadClick = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".pdf,.doc,.docx";
    input.onchange = handleFileSelect;
    input.click();
  };

  return (
    <div className="space-y-6">
      {/* File Upload Area */}
      <Card className="border-2 border-dashed border-gray-300 hover:border-brand-green transition-colors duration-200">
        <CardContent className="p-8 text-center">
          <div className="space-y-4">
            <div className="w-16 h-16 bg-brand-green bg-opacity-10 rounded-full flex items-center justify-center mx-auto">
              <CloudUpload className="text-brand-green" size={32} />
            </div>
            <div>
              <h3 className="text-lg font-medium text-black">Drop your resume here</h3>
              <p className="text-sm text-gray-600">or click to browse files</p>
            </div>
            <div className="text-xs text-gray-500">
              Supported formats: PDF, DOC, DOCX (Max 10MB)
            </div>
            <Button
              onClick={handleUploadClick}
              className="bg-brand-green hover:bg-brand-green-dark"
              disabled={optimizeCVMutation.isPending}
            >
              {optimizeCVMutation.isPending ? "Analyzing..." : "Choose File"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Selected File Info */}
      {selectedFile && (
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <FileText className="text-blue-600" size={20} />
              <div>
                <p className="text-sm font-medium text-blue-800">{selectedFile.name}</p>
                <p className="text-xs text-blue-600">
                  {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Optimization Result */}
      {optimizationResult && (
        <Card className="bg-green-50 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <Lightbulb className="text-green-600 mt-0.5" size={20} />
              <div className="flex-1">
                <h4 className="text-sm font-medium text-green-800">
                  AI Optimization Complete - Score: {optimizationResult.optimizationScore}%
                </h4>
                <div className="mt-2 space-y-1">
                  {optimizationResult.suggestions.slice(0, 3).map((suggestion: string, index: number) => (
                    <p key={index} className="text-sm text-green-700">• {suggestion}</p>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* AI Optimization Preview */}
      {!selectedFile && (
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <Lightbulb className="text-blue-600 mt-0.5" size={20} />
              <div>
                <h4 className="text-sm font-medium text-blue-800">AI Optimization</h4>
                <p className="text-sm text-blue-700">
                  Once uploaded, our AI will analyze your resume and suggest improvements to increase your job application success rate.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
