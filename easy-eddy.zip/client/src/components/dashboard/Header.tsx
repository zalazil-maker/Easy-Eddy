import { Button } from "@/components/ui/button";
import { Bell, Bot } from "lucide-react";
import type { User } from "@shared/schema";

interface HeaderProps {
  user: User;
}

export default function Header({ user }: HeaderProps) {
  const getInitials = (email: string) => {
    return email.split('@')[0].slice(0, 2).toUpperCase();
  };

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <div className="w-8 h-8 bg-brand-green rounded-lg flex items-center justify-center mr-3">
                <Bot className="text-white" size={20} />
              </div>
              <span className="text-xl font-bold text-black">Easy Eddy</span>
            </div>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <a href="#" className="text-gray-700 hover:text-brand-green px-3 py-2 text-sm font-medium">
              Dashboard
            </a>
            <a href="#" className="text-gray-700 hover:text-brand-green px-3 py-2 text-sm font-medium">
              Applications
            </a>
            <a href="#" className="text-gray-700 hover:text-brand-green px-3 py-2 text-sm font-medium">
              Profile
            </a>
            <a href="#" className="text-gray-700 hover:text-brand-green px-3 py-2 text-sm font-medium">
              Settings
            </a>
          </nav>
          
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="relative p-2 text-gray-400 hover:text-brand-green">
              <Bell size={20} />
              <span className="absolute -top-1 -right-1 h-4 w-4 bg-brand-green rounded-full flex items-center justify-center text-xs text-white">
                3
              </span>
            </Button>
            <div className="w-8 h-8 bg-brand-green rounded-full flex items-center justify-center">
              <span className="text-white text-sm font-medium">
                {getInitials(user.email)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
