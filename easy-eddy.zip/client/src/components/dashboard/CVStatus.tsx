import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Lightbulb } from "lucide-react";
import type { User } from "@shared/schema";

interface CVStatusProps {
  userId: number;
}

export default function CVStatus({ userId }: CVStatusProps) {
  const { data: user } = useQuery<User>({
    queryKey: ["/api/users", userId],
  });

  if (!user) return null;

  const optimizationScore = user.cvOptimizationScore || 0;
  const suggestions = user.aiSuggestions || [];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-black">CV Status</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Optimization Score</span>
          <span className="text-sm font-medium text-brand-green">{optimizationScore}%</span>
        </div>
        
        <Progress value={optimizationScore} className="h-2" />
        
        {suggestions.length > 0 && (
          <div className="bg-blue-50 rounded-lg p-3">
            <div className="flex items-start space-x-2">
              <Lightbulb className="text-blue-600 mt-0.5" size={16} />
              <div>
                <p className="text-xs font-medium text-blue-800">AI Suggestion</p>
                <p className="text-xs text-blue-700">
                  {suggestions[0] || "Add more quantified achievements to your experience section"}
                </p>
              </div>
            </div>
          </div>
        )}
        
        <Button className="w-full bg-brand-green text-white hover:bg-brand-green-dark">
          Optimize CV
        </Button>
      </CardContent>
    </Card>
  );
}
