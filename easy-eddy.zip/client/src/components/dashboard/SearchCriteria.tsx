import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { JobCriteria } from "@shared/schema";

interface SearchCriteriaProps {
  userId: number;
}

export default function SearchCriteria({ userId }: SearchCriteriaProps) {
  const { data: criteria } = useQuery<JobCriteria>({
    queryKey: ["/api/users", userId, "job-criteria"],
  });

  if (!criteria) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-black">Search Criteria</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4">
            <p className="text-sm text-gray-600 mb-4">No search criteria set</p>
            <Button className="bg-brand-green hover:bg-brand-green-dark text-white">
              Set Criteria
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  const formatSalary = (min?: number, max?: number) => {
    if (!min && !max) return "Not specified";
    if (!min) return `Up to $${max?.toLocaleString()}`;
    if (!max) return `From $${min.toLocaleString()}`;
    return `$${min.toLocaleString()} - $${max.toLocaleString()}`;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-black">Search Criteria</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div>
          <label className="text-xs font-medium text-gray-600 uppercase tracking-wide">
            Job Titles
          </label>
          <div className="mt-1 flex flex-wrap gap-2">
            {criteria.jobTitles.map((title, index) => (
              <Badge key={index} variant="secondary">
                {title}
              </Badge>
            ))}
          </div>
        </div>
        
        <div>
          <label className="text-xs font-medium text-gray-600 uppercase tracking-wide">
            Locations
          </label>
          <div className="mt-1 flex flex-wrap gap-2">
            {criteria.locations.map((location, index) => (
              <Badge key={index} variant="secondary">
                {location}
              </Badge>
            ))}
          </div>
        </div>
        
        <div>
          <label className="text-xs font-medium text-gray-600 uppercase tracking-wide">
            Salary Range
          </label>
          <p className="text-sm text-gray-800 mt-1">
            {formatSalary(criteria.salaryMin, criteria.salaryMax)}
          </p>
        </div>
        
        <Button className="w-full bg-white text-brand-green border border-brand-green hover:bg-brand-green hover:text-white transition-colors duration-200">
          Edit Criteria
        </Button>
      </CardContent>
    </Card>
  );
}
