import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { useLocation } from "wouter";
import Header from "@/components/dashboard/Header";
import StatusBanner from "@/components/dashboard/StatusBanner";
import StatsGrid from "@/components/dashboard/StatsGrid";
import RecentApplications from "@/components/dashboard/RecentApplications";
import CVStatus from "@/components/dashboard/CVStatus";
import SearchCriteria from "@/components/dashboard/SearchCriteria";
import EmailNotifications from "@/components/dashboard/EmailNotifications";
import type { User } from "@shared/schema";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  
  // Get user ID from session storage or default to 1
  const userId = parseInt(sessionStorage.getItem("easy_eddy_user_id") || "1");
  
  const { data: user, isLoading, error } = useQuery<User>({
    queryKey: ["/api/users", userId],
  });

  useEffect(() => {
    // Redirect to onboarding if user doesn't exist
    if (!isLoading && !user) {
      setLocation("/");
    }
    // Redirect to pending if user is not approved
    if (user && !user.isApproved) {
      setLocation("/access-pending");
    }
  }, [user, isLoading, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 bg-brand-green rounded-lg flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-robot text-white text-lg"></i>
          </div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null; // Will redirect to onboarding
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header user={user} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <StatusBanner userId={userId} />
        
        <StatsGrid userId={userId} />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <RecentApplications userId={userId} />
          </div>
          
          <div className="space-y-6">
            <CVStatus userId={userId} />
            <SearchCriteria userId={userId} />
            <EmailNotifications userId={userId} />
          </div>
        </div>
      </main>
    </div>
  );
}
