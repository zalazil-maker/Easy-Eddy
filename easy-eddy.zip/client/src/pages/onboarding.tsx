import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import ContactInfo from "@/components/onboarding/ContactInfo";
import CVUpload from "@/components/onboarding/CVUpload";
import JobCriteria from "@/components/onboarding/JobCriteria";
import { Bot, X } from "lucide-react";

export default function Onboarding() {
  const [, setLocation] = useLocation();
  const [currentStep, setCurrentStep] = useState(1);
  const [userData, setUserData] = useState({
    email: "",
    phone: "",
    linkedinProfile: "",
    privacyPolicyAccepted: false,
    cvContent: "",
    jobTitles: [],
    locations: [],
    salaryMin: 0,
    salaryMax: 0,
    experienceLevel: "",
    remotePreference: "",
  });

  const totalSteps = 3;
  const progress = (currentStep / totalSteps) * 100;

  const handleNext = async () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    } else {
      // Complete onboarding and redirect to dashboard
      try {
        // Create user
        const userResponse = await fetch("/api/users", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            email: userData.email,
            phone: userData.phone,
            linkedinProfile: userData.linkedinProfile,
            privacyPolicyAccepted: userData.privacyPolicyAccepted,
          }),
        });
        
        if (userResponse.ok) {
          const user = await userResponse.json();
          
          // Create job criteria if provided
          if (userData.jobTitles.length > 0 || userData.locations.length > 0) {
            await fetch(`/api/users/${user.id}/job-criteria`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                jobTitles: userData.jobTitles,
                locations: userData.locations,
                salaryMin: userData.salaryMin,
                salaryMax: userData.salaryMax,
                experienceLevel: userData.experienceLevel,
                remotePreference: userData.remotePreference,
              }),
            });
          }
          
          // Store user ID in session storage for the demo
          sessionStorage.setItem("easy_eddy_user_id", user.id.toString());
          setLocation("/access-pending");
        }
      } catch (error) {
        console.error("Failed to complete onboarding:", error);
      }
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSkip = () => {
    setLocation("/access-pending");
  };

  const getStepTitle = () => {
    switch (currentStep) {
      case 1:
        return "Contact Information";
      case 2:
        return "Upload Your CV/Resume";
      case 3:
        return "Job Search Criteria";
      default:
        return "Setup";
    }
  };

  const getStepDescription = () => {
    switch (currentStep) {
      case 1:
        return "We need your contact details to apply for jobs and send you notifications.";
      case 2:
        return "Upload your resume for AI optimization";
      case 3:
        return "Tell us what kind of jobs you're looking for";
      default:
        return "Let's set up your automated job search";
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <ContactInfo
            data={userData}
            onUpdate={(updates) => setUserData({ ...userData, ...updates })}
          />
        );
      case 2:
        return (
          <CVUpload
            data={userData}
            onUpdate={(updates) => setUserData({ ...userData, ...updates })}
          />
        );
      case 3:
        return (
          <JobCriteria
            data={userData}
            onUpdate={(updates) => setUserData({ ...userData, ...updates })}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-brand-green rounded-lg flex items-center justify-center">
                <Bot className="text-white" size={20} />
              </div>
              <div>
                <CardTitle className="text-xl font-bold text-black">Welcome to Easy Eddy</CardTitle>
                <p className="text-sm text-gray-600">Let's set up your automated job search</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleSkip}
              className="text-gray-400 hover:text-gray-600"
            >
              <X size={20} />
            </Button>
          </div>
        </CardHeader>

        <CardContent className="p-6">
          {/* Progress */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-600">
                Step {currentStep} of {totalSteps}
              </span>
              <span className="text-sm font-medium text-brand-green">
                {Math.round(progress)}% Complete
              </span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* Step Content */}
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-black mb-2">{getStepTitle()}</h3>
              <p className="text-sm text-gray-600 mb-6">{getStepDescription()}</p>
            </div>

            {renderStep()}
          </div>
        </CardContent>

        {/* Actions */}
        <div className="p-6 border-t border-gray-200 bg-gray-50">
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={currentStep === 1 ? handleSkip : handleBack}
              className="px-4 py-2"
            >
              {currentStep === 1 ? "Skip Setup" : "Back"}
            </Button>
            <Button
              onClick={handleNext}
              className="px-6 py-2 bg-brand-green hover:bg-brand-green-dark"
            >
              {currentStep === totalSteps ? "Complete Setup" : "Continue"}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
