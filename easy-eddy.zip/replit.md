# Easy Eddy Job Application Assistant

## Overview

Easy Eddy is a job application automation platform that helps users automatically search for and apply to jobs based on their criteria. The application uses AI to optimize CVs, match job requirements, and provide intelligent job application services. It's built as a full-stack web application with a React frontend and Express backend, using in-memory storage for demo purposes.

## User Preferences

Preferred communication style: Simple, everyday language.

## Admin Access

- **Admin Panel**: Available at `/admin` route
- **Admin Password**: `Bb7er5090866$@` (stored securely in ADMIN_CREDENTIALS.md)
- **Admin Features**: User management, system stats, application monitoring

## Security

The admin panel is password-protected with session-based authentication to prevent unauthorized access to system management features.

## User Approval System

- **New User Flow**: All new users are created in an unapproved state
- **Access Control**: Only approved users can access the dashboard and job automation features
- **Admin Approval**: Admin can approve users through the admin panel at `/admin`
- **Pending Page**: Unapproved users are redirected to `/access-pending` with instructions

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing
- **Form Handling**: React Hook Form with Zod validation
- **UI Components**: Custom component library built on Radix UI primitives

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Database Driver**: @neondatabase/serverless
- **API Design**: RESTful endpoints with JSON responses
- **Development Server**: Vite for frontend development with HMR

### Build System
- **Frontend Build**: Vite for bundling and development
- **Backend Build**: esbuild for server-side bundling
- **TypeScript**: Full-stack TypeScript with shared types
- **Development**: tsx for running TypeScript files directly

## Key Components

### User Management
- User registration and profile management
- CV upload and storage
- Privacy policy acceptance tracking
- LinkedIn profile integration

### Job Search & Automation
- Job criteria configuration (titles, locations, salary, experience)
- Automated job searching across multiple platforms
- Job application tracking and status management
- Match scoring algorithm for job relevance

### AI Integration
- CV optimization using OpenAI GPT-4o
- Job description analysis and matching
- Automated email generation for applications
- AI-powered suggestions for profile improvement

### Email System
- Notification system for application status
- Automated email generation and sending
- Application confirmation emails
- Status update notifications

## Data Flow

### User Onboarding
1. User provides contact information and LinkedIn profile
2. CV upload and AI optimization analysis
3. Job search criteria configuration
4. Account activation and automation setup

### Job Application Process
1. System searches for jobs matching user criteria
2. AI analyzes job compatibility and generates match scores
3. Applications are automatically submitted to qualifying positions
4. Email notifications are sent to users about applications
5. Application status is tracked and updated

### Dashboard Analytics
1. Real-time statistics on applications sent, responses, and interviews
2. CV optimization score tracking
3. Recent application history with status updates
4. Job search criteria management

## External Dependencies

### Core Dependencies
- **Database**: Neon PostgreSQL serverless database
- **AI Service**: OpenAI API for CV optimization and job matching
- **UI Components**: Radix UI primitives for accessible components
- **Styling**: Tailwind CSS for utility-first styling

### Development Dependencies
- **Build Tools**: Vite, esbuild, TypeScript compiler
- **Code Quality**: ESLint, Prettier (implied by setup)
- **Development**: tsx for TypeScript execution

### Job Platform Integration
- Mock job data currently implemented
- Designed for future integration with LinkedIn, Indeed, Glassdoor APIs
- Extensible architecture for adding new job platforms

## Deployment Strategy

### Production Build
- Frontend: Vite builds to `dist/public` directory
- Backend: esbuild bundles server to `dist/index.js`
- Database: Drizzle migrations in `migrations/` directory

### Environment Configuration
- Database URL configuration via environment variables
- OpenAI API key configuration
- Development vs production environment detection

### Database Management
- Drizzle ORM for type-safe database operations
- Migration system for schema changes
- Connection pooling via Neon serverless driver

### Development Workflow
- Hot module replacement for frontend development
- Automatic server restart on backend changes
- Shared TypeScript types between frontend and backend
- Real-time error overlays in development

The application is designed to be easily deployable on platforms like Replit, Vercel, or similar services with minimal configuration changes.